                                                       This is a program for Blood Bank Management system.
                                                                        
                                                                                      By Saz Creation
                                          with help from Sachin S , Ganga Balan , Jinu Celine ,Unni Krishnan , Arun Kumar
****************************************************************************************************************************************************
First:- Copy the files ''BBMS_Main.py","Defaultmysql.py","Help.txt","Background.png" in a single folder

Second:-Run  the file "BBMS_Main.py"  and enjoy

Required Modules :- tkinter , tkcalendar , mysql.connector ,pillow,builtins ,messagebox

****************************************************************************************************************************************************
                                                                           !!!!Hope you like my Code!!!!


							for comments  mail :-
        								   darklordsachin12@gmail.com